<?php

class Database {
    //contains the database parameters
    private $hostname = "localhost";
    private $dbname = "quote";
    private $username = "root";
    private $password = "";

    private $pdo;

    //start connection
    public function __construct() {
        //setting up the pdo class
        $this->pdo = null;
        try{
            $this->pdo = new PDO("mysql:host=$this->hostname;dbname=$this->dbname;", $this->username, $this->password);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Error ". $e->getMessage();
        }


    }

    public function fetchAll($query) {
        $stmt = $this->pdo->query($query);
        $stmt->execute();
        $rowCount = $stmt->rowCount();

        if($rowCount <= 0) {
            //we fetched nothing from the database
            return 0;
        } else {
            return $stmt->fetchAll();
        }
    }

    public function fetchOne($query, $parameter) {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([$parameter]);
        $rowCount = $stmt->rowCount();

        if($rowCount <= 0) {
            return 0;
        } else {
            return $stmt->fetch();
        }
    }

    public function executeCall($username, $calls_allowed, $timeOutSeconds) {
        //we take in 3 arguments here; the username, call allowed, and the seconds needed.
        $query = "SELECT plan, calls_made, time_start, time_end 
            FROM users
            WHERE username = '$username'
        ";

        $stmt = $this->pdo->prepare($query);
        $stmt->execute([$username]);
        $results = $stmt->fetch();

        //variable needed 1598029587
        //IF IT IS TIMEOUT OR EQUAL TO ZERO SET TO TRUE
        /*
         * What we are doing here is checking if the current time (date(time()) - the time_start
         * is greater than or equals to the timeout given
         * or
         * if the timeout for the start for the user is 0
         *
         * IF ANY OF THE ABOVE Condition is true, then its a timeOut (TRUE)
         * */
        $timeOut = date(time()) - $results['time_start'] >= $timeOutSeconds || $results['time_start'] === 0;

        //UPDATE CALLS MADE WITH RESPONSE TO TIME OUT
        $query = "UPDATE users 
            SET calls_made = ";
        $query .= $timeOut ? " 1, time_start = " . date(time()) . " , time_end = " . strtotime("+ $timeOutSeconds seconds") : $results['calls_made'] + 1;
        $query .= " WHERE username = ? ";
        /*
         * update the user if there is a timeout to 1, and set the timestart to current time and the endtime to timeout.
         * if timeOut is false, just increase the calls_made by one.
         * */
        //INSTEAD OF FETCHING AGAIN USING THE SELECT ALL UPDATED VARIABLES
        $results['call_made'] = $timeOut ? 1 : $results['calls_made'] + 1;
        $results['time_end'] = $timeOut ? strtotime("+ $timeOutSeconds seconds") : $results['time_end'];
        echo $query;
        //EXECUTE CODE WITH RESPECT
        if($results['plan'] == "unlimited") {
            $stmt = $this->pdo->prepare($query);
            $stmt->execute([$username]);
            return $results;
        } else {
            //if no time out and calls made is greater than calls allowed to return
            if($timeOut === false && $results['calls_made'] >= $calls_allowed) {
                return -1;
            } else {
                //Grant access
                $stmt = $this->pdo->prepare($query);
                $stmt->execute([$username]);
                return $results;
            }
        }
    }

    public function insertOne($query, $body, $user_id, $category_id, $date) {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([$body, $user_id, $category_id, $date]);
    }

    public function updateOne($query, $body, $category_id, $id) {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([$body, $category_id, $id]);
    }

    public function deleteOne($query, $id) {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([$id]);
    }

    public function insertUser($query, $firstName, $lastName, $password, $username) {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([$firstName, $lastName, $password, $username]);
    }
}