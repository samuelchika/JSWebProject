<?php


class User
{
    private $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function insertUser($query, $parameters, $id) {
        //check if firstname and lastname and password is set in the parameters
        //this request will be a post method, so we have to use the ->

        if(isset($parameters->firstName) && isset($parameters->lastName) && isset($parameters->password))
        {
            //all the required fields are set.
            $firstName = $parameters->firstName;
            $lastName = $parameters->lastName;
            $username = strtolower($firstName) . strtolower($lastName) . $id;
            $password = $parameters->password;
            $this->db->insertUser($query, $firstName, $lastName, $username, $password);
            //we have successfully inserted our data. we have to return what we inputed with an API Key
            return [
              "firstName" => $firstName,
              "lastName" => $lastName,
              "username" => $username,
              "api-key" => base64_encode("$username:$password")
            ];
        } else {
            return -1;
        }
    }
}