<?php
require_once "../../config/Database.php";
require_once "../../models/HttpResponse.php";
require_once "../../models/Quote.php";
require_once "../../models/User.php";
//SET HEADERS
header('Access-Control-Allow-Origin: *'); //enables it allows all call
header('Content-Type: application/json'); //accepts only JSON files
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE'); //the kind of request allowed
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type, Access-Control-Allow-Methods, Authorization, X_Requested-With');
//combiniing all the headers set and other requeired headers.


//instatiate the classes we brought in
$db = new Database();
$quote = new Quote($db);
$http = new HttpResponse();
$user = new User($db);

if($_SERVER['REQUEST_METHOD'] === "POST") {
    $userDetails = json_decode(file_get_contents("php://input"));
    $query = "INSERT INTO users (firstName, lastName, username, password) VALUE (?, ?, ?, ?)";
    $nextIdQuery = "SELECT count(*) AS lastId FROM users";
    $nextId = $db->fetchOne($nextIdQuery, "");
    $result = $user->insertUser($query, $userDetails, $nextId['lastId'] + 1);
    if($result === -1) {
        $http->badRequest("You have to provide Firstnmae, lastname and password to get registered");
    } else {
        http_response_code(200);
        echo json_encode( [
          "datetime" => date("Y-m-d h:i:s:a"),
          "version" => "1.0.0",
          "data" => $result
        ]);
    }

}
