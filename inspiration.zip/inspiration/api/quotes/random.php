<?php
require_once "../../config/Database.php";
require_once "../../models/HttpResponse.php";
require_once "../../models/Quote.php";
require_once "../../models/User.php";
//SET HEADERS
header('Access-Control-Allow-Origin: *'); //enables it allows all call
header('Content-Type: application/json'); //accepts only JSON files
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE'); //the kind of request allowed
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type, Access-Control-Allow-Methods, Authorization, X_Requested-With');
//combiniing all the headers set and other requeired headers.


//instatiate the classes we brought in
$db = new Database();
$quote = new Quote($db);
$http = new HttpResponse();

//check if the user sent in login details
if(!isset($_SERVER['PHP_AUTH_USER']) && !isset($_SERVER['PHP_AUTH_PW'])) {
    //the user did not sent in any authentication detail. we have to send back and error with the httpResponse class
    $http->notAuthorized("You have to Authenticate yourself, before you make use of Quote API");
    exit();
} else {
    //the username and password is set.
    $username = $_SERVER["PHP_AUTH_USER"];
    $password = $_SERVER["PHP_AUTH_PW"];

    //get the details of the user which is trying to gain access
    //check which plan they are on
    $query = "SELECT * FROM users WHERE username = ?";
    $results = $db->fetchOne($query, $username);

    if($results === 0 || $results['password'] !== $password) {
        //wrong credentials
        $http->notAuthorized("Wrong Credentials Provided.");
        exit();
    } else {
        //the write credential was provided
        $user_id = $results['id'];
    }
}

if(isset($_GET['number']) && !filter_var($_GET['number'], FILTER_VALIDATE_INT)) {
    //error
    $http->notAuthorized("Only Valid integers are allowed");
    exit();
}

//we set the limit of number
$limit = (isset($_GET['number'])) ? $_GET['number'] : 1;

$randomQuotes = $quote->fetchRandomQuotes($limit);
$resultInfo = $db->executeCall($username, 1000, 86400);

if($randomQuotes === 0) {
    $http->notFound("No data found!");
} else if ($resultInfo === -1) {
    $http->paymentRequired();
} else {
    $http->OK($resultInfo, $randomQuotes);
}