<?php
    require_once "../../config/Database.php";
    require_once "../../models/HttpResponse.php";
    require_once "../../models/Quote.php";
    require_once "../../models/User.php";
    //SET HEADERS
    header('Access-Control-Allow-Origin: *'); //enables it allows all call
    header('Content-Type: application/json'); //accepts only JSON files
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE'); //the kind of request allowed
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type, Access-Control-Allow-Methods, Authorization, X_Requested-With');
    //combiniing all the headers set and other requeired headers.


    //instatiate the classes we brought in
    $db = new Database();
    $quote = new Quote($db);
    $http = new HttpResponse();

    //check if the user sent in login details
    if(!isset($_SERVER['PHP_AUTH_USER']) && !isset($_SERVER['PHP_AUTH_PW'])) {
        //the user did not sent in any authentication detail. we have to send back and error with the httpResponse class
        $http->notAuthorized("You have to Authenticate yourself, before you make use of Quote API");
        exit();
    } else {
        //the username and password is set.
        $username = $_SERVER["PHP_AUTH_USER"];
        $password = $_SERVER["PHP_AUTH_PW"];

        //get the details of the user which is trying to gain access
        //check which plan they are on
        $query = "SELECT * FROM users WHERE username = ?";
        $results = $db->fetchOne($query, $username);

        if($results === 0 || $results['password'] !== $password) {
            //wrong credentials
            $http->notAuthorized("Wrong Credentials Provided.");
            exit();
        } else {
            //the write credential was provided
            $user_id = $results['id'];
        }
    }

    //check incoming get request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id']) && !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
        //error, only integer is allowed
        $http->badRequest("Only a valid integer is allowed to fetch a single quote");
        exit();
    }
    //if an id was given, then we fetch the quote with the id given, else fetch all quote
    $resultsData = isset($_GET['id']) ? $quote->fetchOneQuote($_GET['id']) : $quote->fetchAllQuotes();
    $resultsInfo = $db->executeCall($username, 1000, 86400);

    if ($resultsData === 0) {
        $message = "NO quote ";
        $message .= isset($_GET['id']) ? "with the id " . $_GET['id'] : "";
        $message .= " was found";
        $http->notFound($message);
    } else if ($resultsInfo === -1) {
        $http->paymentRequired();
    } else {
        $http->OK($resultsInfo, $resultsData);
    }
} else if ($_SERVER['REQUEST_METHOD'] === "POST") {
    //we have to get the input
    $receivedQuotes = json_decode(file_get_contents("php://input"));
    //user id was created when the user logged in
    $results = $quote->insertQuote($receivedQuotes, $user_id);
    $resultsInfo = $db->executeCall($username, 1000, 86400);

    if ($results === -1) {
        //error inserting the quote
        $http->badRequest("Please Provide the body and category id of the post you want to insert");
    } else if ($resultsInfo === -1) {
        $http->paymentRequired();
    } else {
        $http->OK($resultsInfo, $results);
    }
} else if ($_SERVER['REQUEST_METHOD'] === "PUT") {
    //check for ID
    //check if the id is existing.

    //if the id exist, then update the quote
    //when updating, check if some filed exists first or else use the one gotten from the id check to update.
    $quoteResponse = json_decode(file_get_contents("php://input"));
    echo($quoteResponse->id);
    if(!$quoteResponse->id) {
        //id dont exists
        $http->badRequest("Please id is required to update a quote");
        exit();
    }

    //set up query to get the quote by the id
    $query = "SELECT * FROM quotes WHERE id = ?";
    $results = $db->fetchOne($query, $quoteResponse->id);
    if($results === 0) {
        //the post do not exist
        $http->notFound("Quote with the id $quoteResponse->id was not found");
        exit();
    } else if ($user_id !== $results["user_id"]) {
        $http->notAuthorized("You are not authorize to update this quote");
    } else {
        //user can update the quote
        $parameters = [
            "id" => $quoteResponse->id,
            "body" => (!empty($quoteResponse->body)) ? $quoteResponse->body : $results['body'],
            "category_id" => (!empty($quoteResponse->category_id)) ? $quoteResponse->category_id : $results['category_id'],
        ];
        $resultData = $quote->updateQuote($parameters);
        $resultsInfo = $db->executeCall($username, 1000, 86400);

        if($resultsInfo === -1) {
            $http->paymentRequired();
        } else {
            $http->OK($resultsInfo, $results);
        }
    }
} else if ($_SERVER['REQUEST_METHOD'] === "DELETE") {
    //check if the id exist
    //check if the post exist
    //check if the user is the owner of the post
    //if all conditions are meet, then delete the post.
    $quoteId = json_decode(file_get_contents("php://input"));
    if (!$quoteId->id) {
        $http->badRequest("Please provide ID for the post to be deleted.");
        exit();
    }

    $query = "SELECT * FROM quotes WHERE id = ?";
    $results = $db->fetchOne($query, $quoteId->id);

    if ($results === 0) {
        $http->badRequest("The Post ID is invalid!");
        exit();
    }
    //check for user priviledge to delete post
    if ($results['user_id'] !== $user_id) {
        //the use cant make changes.
        $http->notAuthorized("You are not Authorized to delete this post");
        exit();
    }

    //all condition has been met, therefore we can delete the post successfull but check the limit of the user
    $resultData = $quote->deleteQuote($quoteId->id);
    $resultsInfo = $db->executeCall($username, 1000, 86400);
    if($resultsInfo === -1) {
        $http->paymentRequired();
        exit();
    } else {
        //all condition has been meet, we can continue
        $http->OK($resultsInfo, $resultData);
    }

}